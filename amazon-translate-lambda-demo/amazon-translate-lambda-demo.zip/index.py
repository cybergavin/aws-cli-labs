import boto3
from botocore.exceptions import ClientError
import os
import sys

def lambda_handler(event, context):
    
    #boto3 connections
    s3 = boto3.resource('s3')
    translate = boto3.client('translate')

    for record in event['Records']:
        
        #defining variables
        SOURCE_BUCKET_NAME = record['s3']['bucket']['name']
        TARGET_BUCKET_NAME = os.environ['TargetBucketName']
        download_key = record['s3']['object']['key']
        object_name = download_key.split("/")[-1]
        object_input_path = download_key.split("/")[0]
        upload_key = os.environ['TargetLanguageCode'] +"/" + object_input_path + "/" + object_name
        read_path = '/tmp/' + object_name
        write_path = '/tmp/translated-' + object_name

        #creating and opening a new txt file which is where the translated text will be put
        new_file = open(write_path, "w+")
        
        #downloading the file to be translated
        s3.Bucket(SOURCE_BUCKET_NAME).download_file(download_key, read_path)
        
        with open(read_path, "r") as text_file:
            #reading all the content in one step
            all_content = text_file.read() 
            #splitting the content in paragraphs and storing it in an array
            content_array = all_content.split("\n")

        #translating the text using Amazon Translate
        for i in range(len(content_array)):
            if content_array[i] != "":
                if sys.getsizeof(content_array[i]) > 5000:
                    a = content_array[i].split()[:5]
                    print ("Error occurred - please break down the following paragraph into smaller chunks in order to avoid hitting Amazon Translate API limits.")
                    print ("Paragraph starting with\""+' '.join(a)+"...\"")
                else:

                    try:
                        result = translate.translate_text(Text=content_array[i],
                                          SourceLanguageCode = os.environ['SourceLanguageCode'],
                                          TargetLanguageCode = os.environ['TargetLanguageCode'])
                    except ClientError as e:
                        print ("Unexpected error: %s" % e)

                #writing the translated text to local document
                new_file.write(result["TranslatedText"])

                #===if you want to perform the translation operation by each sentence, uncomment this segment of the code===
                #splitting the content by sentences (end of a sentence identified by full stop ".") and storing it in an array
                #    sentence_array = content_array[i].split(".")
                #    for j in range(len(sentence_array)):
                #        if sentence_array[j] != "":
                #            try:
                #                result = translate.translate_text(Text=sentence_array[j],
                #                                  SourceLanguageCode = os.environ['SourceLanguageCode'],
                #                                  TargetLanguageCode = os.environ['TargetLanguageCode'])
                #            except ClientError as e:
                #                print ("Unexpected error: %s" % e)
                #        new_file.write(result["TranslatedText"])
                #        new_file.write(".") 
                new_file.write("\n")
            else:
                new_file.write("\n")

        new_file.close()

        #writing the translated document to S3
        s3.Bucket(TARGET_BUCKET_NAME).upload_file(write_path, upload_key)
        
        #removing the local files
        os.remove(read_path)
        os.remove(write_path)